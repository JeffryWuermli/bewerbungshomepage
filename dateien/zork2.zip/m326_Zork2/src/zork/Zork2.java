package zork;

public class Zork2 {
	
	public static void main(String[] args) {
		
		Game start = new Game();
		start.play();
	}
}
