package zork;

import java.util.ListIterator;

public class Player {
	
	private Items playerItems;
	
	public Player() {
		playerItems = new Items();
	}
	
	public void addPlayerItem(Item item) {
		gesamtGewicht();
		doppeltePruefen(item);
		if(doppeltePruefen(item) == true && (gesamtGewicht() == true)){
			this.playerItems.addItem(item);
			System.out.println("Der Gegenstand wurde erfolgreich aufgenommen.");
		}else if((gesamtGewicht() == false)){
			System.out.println("Du kannst diesen Gegenstand nicht aufnehmen, da das Maximalgewicht von 8 Kg erreicht wurde.");
			System.out.println("Bei bedarf kannst du mit dem Befehl <drop> nicht mehr ben�tigte Gegenst�nde fallen lassen.");
		}
		else if(doppeltePruefen(item) == false) {
			System.out.println("Du kannst diesen Gegenstand nicht aufnehmen, da er bereits in deinem Inventar vorhanden ist.");
		}
	}
	
	public void safeItem() {

	}
	
	public boolean gesamtGewicht() {
		boolean gewichtPruefen = true;
		double gesamtGewicht = 0;
		double gewicht;
		ListIterator<Item> listGewicht = playerItems.getItemList().listIterator();
		
		while(listGewicht.hasNext()) {
			gewicht = listGewicht.next().getGewicht();
			gesamtGewicht = gesamtGewicht + gewicht;
		}
		if(gesamtGewicht < 8) {
			gewichtPruefen = true;
		}
		else {
			gewichtPruefen = false;
		}
		return gewichtPruefen;
	}
	
	public boolean doppeltePruefen(Item item) {
		boolean doppelte = true;
		ListIterator<Item> listDoppelte = playerItems.getItemList().listIterator();
		while(listDoppelte.hasNext()) {
			if(listDoppelte.next() == item) {
				doppelte = false;
			}
			else {
				doppelte = true;
			}
		}
		if(listDoppelte.hasNext() == false) {
			doppelte = true;
		}
		return doppelte;
	}
	
	public Items getPlayerItems() {
		return playerItems;
	}
}
