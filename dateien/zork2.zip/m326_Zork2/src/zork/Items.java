package zork;

import java.util.ArrayList;
import java.util.ListIterator;

public class Items {
	
	private ArrayList<Item> itemList;
	private ListIterator<Item> listItem;

	public Items() {
		super();
		itemList = new ArrayList<Item>();
		listItem = itemList.listIterator();
		
	}

	public void addItem(Item item) {
		itemList.add(item);
	}
	
	
	public void addItem(String beschreibung, double gewicht) {
		itemList.add(new Item(beschreibung,gewicht));
	}
	
	
	public Item getItem(String beschreibung) {
		Item item = null;
		
		while(listItem.hasNext()) {
			item = listItem.next();
			if(listItem.next().getBeschreibung().equals(beschreibung)) {
				return item;
			}else {
				return null;
			}
		}		
		return null;		
	}
	
	public ArrayList<Item> getItemList() {
		return itemList;
	}

	public void setItemList(ArrayList<Item> itemList) {
		this.itemList = itemList;
	}
	
	
	public boolean removeItem(String beschreibung) {
		return false;
	}
	
	public void removeItem(ArrayList<Item> items, Item item) {
		items.remove(item);
	}
}
