package zork;

public class Item {

	private String beschreibung;
	private double gewicht;

	public Item() {
		super();
	}

	public Item(String beschreibung, double gewicht) {
		super();
		this.beschreibung = beschreibung;
		this.gewicht = gewicht;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public double getGewicht() {
		return gewicht;
	}

	public void setGewicht(double gewicht) {
		this.gewicht = gewicht;
	}

	public String toString() {
		return "Gegenstand: " + beschreibung + " - Gewicht: " + gewicht + " Kg";
	}

}
