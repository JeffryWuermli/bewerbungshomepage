<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"/>
		<title>Buchhaltung</title>
		<link rel="stylesheet" type="text/css" href="media/style.css"/>
	</head>

	<body>
		<?php
			session_start();

			if(isset($_SESSION["login"])){
							echo "<table class='menu' cellpadding='0' cellspacing='0' width='100%'>";
							echo "<tr>";
								echo "<th><a href='index.php'>Home</a></th>";
								echo "<th><a href='accounts.php'>Kontenplan</a></th>";
								echo "<th><a href='book.php'>Hauptbuch</a></th>";
								echo "<th><a href='booking.php'>Buchung</a></th>";
							echo "</tr>";
						echo "</table>";

						echo "<h1>Kontenplan</h1>";

						echo "<h3>Aktiven/Passiven</h3>";

					$connect = mysqli_connect("", "root", "");

					mysqli_select_db($connect, "buchhaltung");

					$konto_alle = mysqli_query($connect, "SELECT konten.kontonummer, konten.beschreibung,
															IF(SUM(
																CASE
																	WHEN buchungen.habenkonto = konten.kontonummer
																	THEN buchungen.betrag
																END) > 0,
																IF(SUM(
																	CASE
																		WHEN buchungen.sollkonto = konten.kontonummer
																		THEN buchungen.betrag
																		END) > 0,
																SUM(
																	CASE
																		WHEN buchungen.sollkonto = konten.kontonummer
																		THEN buchungen.betrag
																		END) - (SELECT 
																						SUM(buchungen.betrag) 
																						FROM buchungen 
																						WHERE buchungen.habenkonto = konten.kontonummer
																						GROUP BY buchungen.habenkonto),
																0 - (SELECT 
																						SUM(buchungen.betrag) 
																						FROM buchungen 
																						WHERE buchungen.habenkonto = konten.kontonummer
																						GROUP BY buchungen.habenkonto)),
																SUM(
																	CASE
																		WHEN buchungen.sollkonto = konten.kontonummer
																		THEN buchungen.betrag
																		END) - 0) AS saldo
															FROM buchungen, konten
															GROUP BY konten.beschreibung
															ORDER BY konten.kontonummer ASC");

					echo "<table cellpadding='0' cellspacing='0'>";
					echo "<tr><th>Nr.</th><th>Bezeichung</th><th align='right'>Saldo</th><th align='right'>Saldo</th></tr>";
						
					$links = array();

					while($datensatz1 = mysqli_fetch_assoc($konto_alle)){
						array_push($links, $datensatz1['kontonummer']);
					}

					mysqli_data_seek($konto_alle, 0); 

					while ($datensatz1 = mysqli_fetch_assoc($konto_alle)){
						if($datensatz1["kontonummer"] < 2000){
							for($i=0; $i < count($links); $i++){
								if($links[$i] == $datensatz1["kontonummer"]){
									echo "<tr><td><a href='account_" . $links[$i] . ".php'>" . 
										$datensatz1["kontonummer"] . 
										"</a></td><td>" . 
										$datensatz1["beschreibung"] . 
										"</td><td align='right'>" . 
										$datensatz1["saldo"] . 
										"</td><td>&nbsp;</td></tr>";
								}
							}
						}
						else if($datensatz1["kontonummer"] >= 2000 && $datensatz1["kontonummer"] < 3000){
							$saldo_rechnung = $datensatz1["saldo"] - $datensatz1["saldo"] * 2;
							for($i=0; $i < count($links); $i++){
								if($links[$i] == $datensatz1["kontonummer"]){
									echo "<tr><td><a href='account_" . $links[$i] . ".php'>" . 
										$datensatz1["kontonummer"] . 
										"</a></td><td>" . 
										$datensatz1["beschreibung"] . 
										"</td><td align='right'>&nbsp;</td><td>" . 
										$saldo_rechnung . 
										"</td></tr>";
								}
							}
						}
					}

					mysqli_data_seek($konto_alle, 0); 

					echo "</table>";

					echo "<h3>Aufwand/Ertrag</h3>";

					echo "<table cellpadding='0' cellspacing='0'>";
						echo "<tr><th>Nr.</th><th>Bezeichung</th><th align='right'>Saldo</th><th align='right'>Saldo</th></tr>";

						while($datensatz1 = mysqli_fetch_assoc($konto_alle)){
							if($datensatz1["kontonummer"] >= 4000 && $datensatz1["kontonummer"] < 5000){
								for($i=0; $i < count($links); $i++){
									if($links[$i] == $datensatz1["kontonummer"]){
										echo "<tr><td><a href='account_" . $links[$i] . ".php'>" . 
											$datensatz1["kontonummer"] . 
											"</a></td><td>" . 
											$datensatz1["beschreibung"] . 
											"</td><td align='right'>" . 
											$datensatz1["saldo"] . 
											"</td><td>&nbsp;</td></tr>";
									}
								}
							}
							else if($datensatz1["kontonummer"] >= 3000 && $datensatz1["kontonummer"] < 4000){
								$saldo_rechnung = $datensatz1["saldo"] - $datensatz1["saldo"] * 2;
								for($i=0; $i < count($links); $i++){
									if($links[$i] == $datensatz1["kontonummer"]){
										echo "<tr><td><a href='account_" . $links[$i] . ".php'>" . 
											$datensatz1["kontonummer"] . 
											"</a></td><td>" . 
											$datensatz1["beschreibung"] . 
											"</td><td align='right'>&nbsp;</td><td>" . 
											$saldo_rechnung . 
											"</td></tr>";
									}
								}
							}
						}
						echo "</table>";
			}
			else{
				echo "<p>Bitte melde dich zuerst an!";	
			}

	?>



	</body>

</html>