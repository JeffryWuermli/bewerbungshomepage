-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 25. Sep 2019 um 17:12
-- Server-Version: 10.1.37-MariaDB
-- PHP-Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `buchhaltung`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `buchungen`
--

CREATE TABLE `buchungen` (
  `buchungsnr` int(11) NOT NULL,
  `beschreibung` varchar(50) NOT NULL,
  `betrag` float NOT NULL,
  `sollkonto` int(11) NOT NULL,
  `habenkonto` int(11) NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `buchungen`
--

INSERT INTO `buchungen` (`buchungsnr`, `beschreibung`, `betrag`, `sollkonto`, `habenkonto`, `datum`) VALUES
(0, 'Bareinlage', 1000, 1000, 2100, '2004-01-01'),
(1, 'Otto, u/Kauf, 80 Uhren', 800, 4000, 1000, '2004-01-01'),
(2, 'Strasse, u/Verkauf, 20 Uhren', 400, 1000, 3000, '2004-01-08'),
(3, 'Strasse, u/Verkauf, 15 Uhren', 300, 1000, 3000, '2004-01-15'),
(4, 'Strasse, u/Verkauf, 22 Uhren', 440, 1000, 3000, '2004-01-22'),
(5, 'Inventur, 23 Uhren', 230, 1050, 4000, '2004-01-31'),
(6, 'ewrw', 5555560, 1050, 3000, '2019-04-02'),
(7, 'xkjfhsdlkjfks', 555, 2100, 2100, '2019-05-21');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `konten`
--

CREATE TABLE `konten` (
  `kontonummer` int(11) NOT NULL,
  `beschreibung` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `konten`
--

INSERT INTO `konten` (`kontonummer`, `beschreibung`) VALUES
(1000, 'Kasse'),
(1050, 'Warenbestand'),
(2100, 'Eigenkapital'),
(3000, 'Warenertrag'),
(4000, 'Warenaufwand');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `benutzername` varchar(30) NOT NULL,
  `passwort` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `login`
--

INSERT INTO `login` (`id`, `benutzername`, `passwort`) VALUES
(1, 'jeffry', '1234'),
(3, 'ramon', '1234'),
(4, 'leyla', '1234');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `buchungen`
--
ALTER TABLE `buchungen`
  ADD PRIMARY KEY (`buchungsnr`),
  ADD KEY `habenkonto` (`habenkonto`),
  ADD KEY `sollkonto` (`sollkonto`);

--
-- Indizes für die Tabelle `konten`
--
ALTER TABLE `konten`
  ADD PRIMARY KEY (`kontonummer`);

--
-- Indizes für die Tabelle `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `buchungen`
--
ALTER TABLE `buchungen`
  MODIFY `buchungsnr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT für Tabelle `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `buchungen`
--
ALTER TABLE `buchungen`
  ADD CONSTRAINT `buchungen_ibfk_1` FOREIGN KEY (`habenkonto`) REFERENCES `konten` (`kontonummer`),
  ADD CONSTRAINT `buchungen_ibfk_2` FOREIGN KEY (`sollkonto`) REFERENCES `konten` (`kontonummer`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
