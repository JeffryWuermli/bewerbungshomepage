<!DOCTYPE HTML
		PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"/>
	<title>Buchhaltung</title>
	<link rel="stylesheet" type="text/css" href="media/style.css"/>
</head>

<body>


<!-- Menu -->

<table class="menu" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<th><a href="index.php">Home</a></th>
		<th><a href="accounts.php">Kontenplan</a></th>
		<th><a href="book.php">Hauptbuch</a></th>
		<th><a href="booking.php">Buchung</a></th>
	</tr>
</table>

<!-- Inhalt -->


<?php
	session_start();

	$con = mysqli_connect("", "root", "");

	mysqli_select_db($con, "buchhaltung");

	$login = mysqli_query($con, "SELECT * FROM login");

	if(isset($_POST["abmelden"])){
		unset($_POST["abmelden"]);
		unset($_POST["benutzername"]);
		unset($_POST["passwort"]);
		session_destroy();
	}

	if(isset($_POST["benutzername"]) && isset($_POST["passwort"])){

		while($dsatz = mysqli_fetch_assoc($login)){
			if($dsatz["benutzername"] == $_POST["benutzername"] && $dsatz["passwort"] == $_POST["passwort"]){
				$_SESSION["benutzername"] = $_POST["benutzername"];
				$_SESSION["passwort"] = $_POST["passwort"];
				$_SESSION["login"] = 1;
			}
		}	
	}

	if(isset($_SESSION["benutzername"]) && isset($_SESSION["passwort"])){
		echo "<h1>Buchhaltung</h1>";

		echo "<p>Willkommen beim Buchhaltungssystem von Ramon Brechbühler, Leyla Büchel und Jeffry Würmli.</p>";
		echo "<p>Du bist als " . $_SESSION['benutzername'] . " eingeloggt.</p>";
		echo "<form action='index.php' method='post'>";
			echo "<input type='submit' name='abmelden' value='abmelden'>";
		echo "</form>";


	}
	else{
		echo "<h1>Buchhaltung</h1>";

		echo "<p>Willkommen beim Buchhaltungssystem von Ramon Brechbühler, Leyla Büchel und Jeffry Würmli.</p>";
		echo "<p>Bitte logge dich ein.</p>";

		echo "<form action='index.php' method='post'>";
			echo "<table>";
				echo "<tr>";
					echo "<td>Benutzername</td>";
					echo "<td><input type='text' name='benutzername'></td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td>Passwort</td>";
					echo "<td><input type='password' name='passwort'></td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td><input type='submit' name='login' value='LogIn'></td>";
					echo "<td></td>";
				echo "</tr>";
			echo "</table>";
		echo "</form>";
	}



	

?>

</body>

</html>