<!DOCTYPE HTML
		PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"/>
	<title>Buchhaltung</title>
	<link rel="stylesheet" type="text/css" href="media/style.css"/>
</head>

<body>

<!-- Menu -->

<table class="menu" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<th><a href="index.php">Home</a></th>
		<th><a href="accounts.php">Kontenplan</a></th>
		<th><a href="book.php">Hauptbuch</a></th>
		<th><a href="booking.php">Buchung</a></th>
	</tr>
</table>

<!-- Inhalt -->

<?php
	session_start();
	
	$connect = mysqli_connect("", "root", "");

	mysqli_select_db($connect, "buchhaltung");

	$buchungen = mysqli_query($connect, "SELECT * FROM buchungen GROUP BY buchungen.buchungsnr ORDER BY datum");

	echo "<h1>Hauptbuch</h1>";

	echo "<table cellpadding='0' cellspacing='0'>";
		echo "<tr><th>Datum</th><th>Sollkonto</th><th>Habenkonto</th><th>Text</th><th align='right'>Betrag</th></tr>";
		while($datensatz = mysqli_fetch_assoc($buchungen)){			
			echo "<tr><td>" . $datensatz["datum"] . "</td><td>" . $datensatz["sollkonto"] . "</td><td>" . $datensatz["habenkonto"] ."</td><td>" . 
			$datensatz["beschreibung"] . "</td><td align='right'>" . $datensatz["betrag"] . "</td></tr>";
		}
	echo "</table>";

?>

</body>

</html>