<!DOCTYPE HTML
		PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"/>
	<title>Buchhaltung</title>
	<link rel="stylesheet" type="text/css" href="media/style.css"/>
</head>

<body>

<!-- Menu -->

<table class="menu" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<th><a href="index.php">Home</a></th>
		<th><a href="accounts.php">Kontenplan</a></th>
		<th><a href="book.php">Hauptbuch</a></th>
		<th><a href="booking.php">Buchung</a></th>
	</tr>
</table>

<!-- Inhalt -->

<?php

	session_start();

	$connect = mysqli_connect("", "root", "");

	mysqli_select_db($connect, "buchhaltung");

	$konto = mysqli_query($connect, "SELECT buchungen.datum, IF(sollkonto = 1050, buchungen.habenkonto, buchungen.sollkonto) AS gegenkonto, 
											buchungen.beschreibung, IF(buchungen.habenkonto = 1050, (buchungen.betrag - (buchungen.betrag * 2)), buchungen.betrag) AS betragtot 
									FROM buchungen 
									WHERE buchungen.sollkonto = 1050 OR buchungen.habenkonto = 1050
									ORDER BY buchungen.datum");

	echo "<h1>Konto 1050: Warenbestand</h1>";

	echo "<table cellpadding='0' cellspacing='0'>";
		echo "<tr><th>Datum</th><th>Gegenkonto</th><th>Text</th><th>Soll</th><th>Haben</th></tr>";

		while($datensatz = mysqli_fetch_assoc($konto)){

			if($datensatz['betragtot'] < 0){
				$haben = $datensatz['betragtot'];
				$haben = $haben - ($haben * 2);
				$soll = null;
			}else{
				$soll = $datensatz['betragtot'];
				$haben = null;
			}
			echo "<tr><td>" . $datensatz['datum'] . "</td><td>" . $datensatz['gegenkonto'] . "</td><td>" . $datensatz['beschreibung'] . "</td><td align='right'>" . $soll . "</td><td>" . $haben . "</td></tr>";
		}
	echo "</table>";

?>

</body>

</html>