<!DOCTYPE HTML
		PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"/>
	<title>Buchhaltung</title>
	<link rel="stylesheet" type="text/css" href="media/style.css"/>
</head>

<body>

<!-- Menu -->

<table class="menu" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<th><a href="index.php">Home</a></th>
		<th><a href="accounts.php">Kontenplan</a></th>
		<th><a href="book.php">Hauptbuch</a></th>
		<th><a href="booking.php">Buchung</a></th>
	</tr>
</table>

<!-- Inhalt -->

<?php
	session_start();

	$connect = mysqli_connect("", "root", "");

	mysqli_select_db($connect, "buchhaltung");

	$konten = mysqli_query($connect, "SELECT konten.kontonummer FROM konten");

	$datum = date("Y-m-d");

	if(isset($_POST["buchen"])){
		$sollkonto = $_POST["sollkonto"];
		$habenkonto = $_POST["habenkonto"];
		$text = $_POST["text"];
		$betrag = $_POST["betrag"];

		mysqli_query($connect, "INSERT INTO buchungen (buchungsnr, datum, sollkonto, habenkonto, beschreibung, betrag) VALUES ('', '$datum', '$sollkonto', '$habenkonto', '$text', '$betrag')");
?>
		<script>
			alert("Die Buchung wurde erfolgreich getätigt!");
		</script>
<?php
	}
?>
	<h1>Buchung</h1>

	<form action="booking.php" method="POST">
		<p>Sollkonto: 
					<select name="sollkonto">
						<?php
							while($datensatz = mysqli_fetch_assoc($konten)){
								echo "<option value='" . $datensatz['kontonummer'] . "'>" . $datensatz['kontonummer'] . "</option>";
							}
							mysqli_data_seek($konten, 0);
						 ?>
					</select></p>

		

		<p>Habenkonto: 
					<select name="habenkonto">
						<?php
							while($datensatz = mysqli_fetch_assoc($konten)){
								echo "<option value='" . $datensatz['kontonummer'] . "'>" . $datensatz['kontonummer'] . "</option>";
							}
						?>
					</select></p>
		
		<p>Text: <input type="text" name="text"></p>
		<p>Betrag: <input type="number" name="betrag"></p>
		<p><input type="submit" name="buchen" value="Buchung bestätigen"></p>
	</form>

</body>

</html>